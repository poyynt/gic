name="gic"
version="4.0.0"
url="https://github.com/poyynt/gic/"
author="Parsa Torbati"
author_email="parsa@programmer.net"

