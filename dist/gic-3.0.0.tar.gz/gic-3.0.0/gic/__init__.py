name="gic"
version="3.0.0"
url="https://github.com/poyynt/"
author="Parsa Torbati"
author_email="parsa@programmer.net"

