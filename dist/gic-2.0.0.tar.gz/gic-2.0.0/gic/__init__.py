name="gic"
version="2.0.0"
url="https://github.com/poyynt/"
author="Parsa Torbati"
author_email="parsa@programmer.net"

